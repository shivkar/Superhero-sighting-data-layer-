/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sg.superherosightings.dao;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author SHIVALI
 */
public class PowersDaoDBTest {
    
    public PowersDaoDBTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getPowerById method, of class PowersDaoDB.
     */
    @Test
    public void testGetPowerById() {
    }

    /**
     * Test of getAllPowers method, of class PowersDaoDB.
     */
    @Test
    public void testGetAllPowers() {
    }

    /**
     * Test of addPower method, of class PowersDaoDB.
     */
    @Test
    public void testAddPower() {
    }

    /**
     * Test of updatePower method, of class PowersDaoDB.
     */
    @Test
    public void testUpdatePower() {
    }

    /**
     * Test of deletePowerById method, of class PowersDaoDB.
     */
    @Test
    public void testDeletePowerById() {
    }
    
}
